Just open this project for VScode and use Live Server extension to run it:https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer

After installation just press on "index.html" open with live server by clicking right of computer mouse.